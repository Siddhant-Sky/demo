package com.hcsc.provider.roster.constants;

public class ProviderRosterConstants {

	public static final String ROSTER_EXCEPTION_MSG = "Internal Server Error";

	public ProviderRosterConstants() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
}
