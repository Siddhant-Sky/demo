package com.hcsc.provider.roster.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.hcsc.provider.roster.RosterApplication;
import com.hcsc.provider.roster.daoImpl.ProviderRosterDaoImpl;
import com.hcsc.provider.roster.model.ProviderRoster;

@RestController
public class ProviderRosterController {
	Logger log=LoggerFactory.getLogger(RosterApplication.class);
	@GetMapping("/test")
	public List<ProviderRoster> getAllProviders(){
		return ProviderRosterDaoImpl.getAllProviders();
	}
	
	@PostMapping("/test/addProvider")
	public ProviderRoster addProvider(@RequestBody ProviderRoster provider) {
		return ProviderRosterDaoImpl.addProvider(provider);
	}
}