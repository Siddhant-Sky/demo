package com.hcsc.provider.roster.dao;

import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Repository;

import com.hcsc.provider.roster.dto.ProviderRosterDtoResponse;
@Repository
public interface ProviderRosterDao{
	
	public List<ProviderRosterDtoResponse> searchRosterDetails(Map<String,String> modelMap);
	public List<ProviderRosterDtoResponse> getProviders();
}
