package com.hcsc.provider.roster.daoImpl;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.springframework.stereotype.Repository;

import com.hcsc.provider.roster.dao.ProviderRosterDao;
import com.hcsc.provider.roster.dto.ProviderRosterDtoResponse;
import com.hcsc.provider.roster.model.ProviderRoster;
@Repository
public  class ProviderRosterDaoImpl implements ProviderRosterDao{
	private static Map<Long, ProviderRoster> provider = new HashMap<>();
	private static int index= 2;
	static {
		ProviderRoster roster1= new ProviderRoster(1,12,54,"Siddhant Kumar","Siddhant",
				"Kumar",2,45,78,"Siddhant","Kumar");
		ProviderRoster roster2= new ProviderRoster(2,43,5,"Kuendrak Tobbgyal","Kuendrak",
				"Tobbgyal",2,45,78,"Kuendrak","Tobbgyal");
		provider.put(1L, roster1);
		provider.put(2L, roster2);	
	}
	public static List<ProviderRoster> getAllProviders() {
		return new ArrayList<>(provider.values());
	}
	public static ProviderRoster addProvider(ProviderRoster providers) {
		index += 1;
		providers.setProviderId(index);
		provider.put((long) index, providers);
		return providers;
	}
	@Override
	public List<ProviderRosterDtoResponse> searchRosterDetails(Map<String, String> modelMap) {
		// TODO Auto-generated method stub
		return null;
	}
	@Override
	public List<ProviderRosterDtoResponse> getProviders() {
		// TODO Auto-generated method stub
		return null;
	}
	
}
