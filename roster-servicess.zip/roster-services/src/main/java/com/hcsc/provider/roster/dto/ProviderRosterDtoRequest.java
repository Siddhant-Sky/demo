package com.hcsc.provider.roster.dto;

public class ProviderRosterDtoRequest {
}
