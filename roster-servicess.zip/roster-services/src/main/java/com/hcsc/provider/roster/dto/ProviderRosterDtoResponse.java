package com.hcsc.provider.roster.dto;

public class ProviderRosterDtoResponse {
	private int providerId;
	private int pfin;
	private int billPfin;
	private String billPfinName;
	private String billPfinFirstName;
	private String billPfinLastName;
	private long npi;
	private long tin;
	private long palId;
	private String firstName;
	private String lastName;
	public int getProviderId() {
		return providerId;
	}
	public void setProviderId(int providerId) {
		this.providerId = providerId;
	}
	public int getPfin() {
		return pfin;
	}
	public void setPfin(int pfin) {
		this.pfin = pfin;
	}
	public int getBillPfin() {
		return billPfin;
	}
	public void setBillPfin(int billPfin) {
		this.billPfin = billPfin;
	}
	public String getBillPfinName() {
		return billPfinName;
	}
	public void setBillPfinName(String billPfinName) {
		this.billPfinName = billPfinName;
	}
	public String getBillPfinFirstName() {
		return billPfinFirstName;
	}
	public void setBillPfinFirstName(String billPfinFirstName) {
		this.billPfinFirstName = billPfinFirstName;
	}
	public String getBillPfinLastName() {
		return billPfinLastName;
	}
	public void setBillPfinLastName(String billPfinLastName) {
		this.billPfinLastName = billPfinLastName;
	}
	public long getNpi() {
		return npi;
	}
	public void setNpi(long npi) {
		this.npi = npi;
	}
	public long getTin() {
		return tin;
	}
	public void setTin(long tin) {
		this.tin = tin;
	}
	public long getPalId() {
		return palId;
	}
	public void setPalId(long palId) {
		this.palId = palId;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	@Override
	public String toString() {
		return "ProviderRosterResponse [providerId=" + providerId + ", pfin=" + pfin + ", billPfin=" + billPfin
				+ ", billPfinName=" + billPfinName + ", billPfinFirstName=" + billPfinFirstName + ", billPfinLastName="
				+ billPfinLastName + ", npi=" + npi + ", tin=" + tin + ", palId=" + palId + ", firstName=" + firstName
				+ ", lastName=" + lastName + "]";
	}
	public ProviderRosterDtoResponse(int providerId, int pfin, int billPfin, String billPfinName, String billPfinFirstName,
			String billPfinLastName, long npi, long tin, long palId, String firstName, String lastName) {
		super();
		this.providerId = providerId;
		this.pfin = pfin;
		this.billPfin = billPfin;
		this.billPfinName = billPfinName;
		this.billPfinFirstName = billPfinFirstName;
		this.billPfinLastName = billPfinLastName;
		this.npi = npi;
		this.tin = tin;
		this.palId = palId;
		this.firstName = firstName;
		this.lastName = lastName;
	}
	public ProviderRosterDtoResponse() {
		super();
		// TODO Auto-generated constructor stub
	}
	
}
