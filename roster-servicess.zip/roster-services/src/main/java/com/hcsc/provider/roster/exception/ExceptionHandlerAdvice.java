package com.hcsc.provider.roster.exception;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.context.request.WebRequest;
import com.hcsc.provider.roster.utility.LogUtils;

@RestControllerAdvice
public class ExceptionHandlerAdvice {
	private static final Logger logger=LoggerFactory.getLogger(ExceptionHandlerAdvice.class);
	@ExceptionHandler(ProviderRosterException.class)
	public final ResponseEntity<ProviderRosterExceptionResponse> handleUnknownException(ProviderRosterException exception,WebRequest webRequest)
	{
		logger.error("Error: {}",exception.getMessage());
		logger.error("Error: ",LogUtils.MessageCodeType.DB,"");
		ProviderRosterExceptionResponse response = new ProviderRosterExceptionResponse(HttpStatus.INTERNAL_SERVER_ERROR.value(),exception.getMessage(), webRequest.getDescription(false));
		return new ResponseEntity<ProviderRosterExceptionResponse>(response,HttpStatus.INTERNAL_SERVER_ERROR);
		
	}
}
