package com.hcsc.provider.roster.exception;

import com.hcsc.provider.roster.constants.ProviderRosterConstants;

public class ProviderRosterException extends RuntimeException{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public ProviderRosterException() {
		super(ProviderRosterConstants.ROSTER_EXCEPTION_MSG);
		
	}

}
