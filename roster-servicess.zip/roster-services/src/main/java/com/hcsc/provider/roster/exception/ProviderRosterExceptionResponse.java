package com.hcsc.provider.roster.exception;

public class ProviderRosterExceptionResponse {

	private int errorCode;
	
	private String description;
	
	private String message;

	public ProviderRosterExceptionResponse() 
	{
		
	}

	public ProviderRosterExceptionResponse(int errorCode, String description, String message) {
		super();
		this.errorCode = errorCode;
		this.description = description;
		this.message = message;
	}

	public int getErrorCode() {
		return errorCode;
	}

	public void setErrorCode(int errorCode) {
		this.errorCode = errorCode;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	@Override
	public String toString() {
		return "ProviderRosterExceptionResponse [errorCode=" + errorCode + ", description=" + description + ", message="
				+ message + "]";
	}
	
	
	
}
