package com.hcsc.provider.roster.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
@Entity
@Table(name = "dbo.provider")
public class ProviderRoster implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "provider_id")
	private int providerId;
	@Column(name = "pfin")
	private int pfin;
	@Column(name = "bill_pfin")
	private int billPFIN;
	@Column(name = "bill_pfin_name")
	private String billPFIName;
	@Column(name = "bill_pfin_first_name")
	private String billPFINFirstName;
	@Column(name = "bill_pfin_last_name")
	private String billPFINLastName;
	@Column(name = "npi")
	private int npi;
	@Column(name = "tin")
	private int tin;
	@Column(name = "pal_id")
	private int palId;
	@Column(name = "first_name")
	private String firstName;
	@Column(name = "last_name")
	private String lastName;
	public int getProviderId() {
		return providerId;
	}
	public void setProviderId(int providerId) {
		this.providerId = providerId;
	}
	public int getPfin() {
		return pfin;
	}
	public void setPfin(int pfin) {
		this.pfin = pfin;
	}
	public int getBillPFIN() {
		return billPFIN;
	}
	public void setBillPFIN(int billPFIN) {
		this.billPFIN = billPFIN;
	}
	public String getBillPFIName() {
		return billPFIName;
	}
	public void setBillPFIName(String billPFIName) {
		this.billPFIName = billPFIName;
	}
	public String getBillPFINFirstName() {
		return billPFINFirstName;
	}
	public void setBillPFINFirstName(String billPFINFirstName) {
		this.billPFINFirstName = billPFINFirstName;
	}
	public String getBillPFINLastName() {
		return billPFINLastName;
	}
	public void setBillPFINLastName(String billPFINLastName) {
		this.billPFINLastName = billPFINLastName;
	}
	public int getNpi() {
		return npi;
	}
	public void setNpi(int npi) {
		this.npi = npi;
	}
	public int getTin() {
		return tin;
	}
	public void setTin(int tin) {
		this.tin = tin;
	}
	public int getPalId() {
		return palId;
	}
	public void setPalId(int palId) {
		this.palId = palId;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	public ProviderRoster() {
		super();
		// TODO Auto-generated constructor stub
	}
	public ProviderRoster(int providerId, int pfin, int billPFIN, String billPFIName, String billPFINFirstName,
			String billPFINLastName, int npi, int tin, int palId, String firstName, String lastName) {
		super();
		this.providerId = providerId;
		this.pfin = pfin;
		this.billPFIN = billPFIN;
		this.billPFIName = billPFIName;
		this.billPFINFirstName = billPFINFirstName;
		this.billPFINLastName = billPFINLastName;
		this.npi = npi;
		this.tin = tin;
		this.palId = palId;
		this.firstName = firstName;
		this.lastName = lastName;
	}
	@Override
	public String toString() {
		return "ProviderRoster [providerId=" + providerId + ", pfin=" + pfin + ", billPFIN=" + billPFIN
				+ ", billPFIName=" + billPFIName + ", billPFINFirstName=" + billPFINFirstName + ", billPFINLastName="
				+ billPFINLastName + ", npi=" + npi + ", tin=" + tin + ", palId=" + palId + ", firstName=" + firstName
				+ ", lastName=" + lastName + "]";
	}
	
}
