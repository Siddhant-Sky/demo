package com.hcsc.provider.roster.service;

import java.util.List;
import java.util.Map;

import com.hcsc.provider.roster.dto.ProviderRosterDtoResponse;

public interface ProviderRosterService {
	public static List<ProviderRosterDtoResponse> searchRosterDetails(Map<String,String> rosterDetails) {
		// TODO Auto-generated method stub
		return null;
	}
	public static List<ProviderRosterDtoResponse> getProviders() {
		// TODO Auto-generated method stub
		return null;
	}
}
