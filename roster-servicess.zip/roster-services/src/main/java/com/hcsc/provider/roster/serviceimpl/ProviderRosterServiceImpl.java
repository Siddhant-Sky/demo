package com.hcsc.provider.roster.serviceimpl;

import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hcsc.provider.roster.dao.ProviderRosterDao;
import com.hcsc.provider.roster.dto.ProviderRosterDtoResponse;
import com.hcsc.provider.roster.exception.ExceptionHandlerAdvice;
@Service
public class ProviderRosterServiceImpl implements ProviderRosterDao{
	@Autowired
	ProviderRosterDao providerRosterServicesDao;
	private static final Logger logger=LoggerFactory.getLogger(ExceptionHandlerAdvice.class);
	public List<ProviderRosterDtoResponse> searchRosterDetails(Map<String,String> modelMap){
		List<ProviderRosterDtoResponse> responses= providerRosterServicesDao.searchRosterDetails(modelMap);
		logger.info("Response: " + responses);
		return responses;
	}
	public List<ProviderRosterDtoResponse> getProviders(){
		return providerRosterServicesDao.getProviders();
	}
 
}
