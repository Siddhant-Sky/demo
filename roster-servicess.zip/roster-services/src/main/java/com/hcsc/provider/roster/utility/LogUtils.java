package com.hcsc.provider.roster.utility;

public class LogUtils {
	public static final class MessageCodeType
	{
		public static final String DB= "CMN.TECH.ERROR.5004";
		public static final String GENERIC="CMN.TECH.ERROR.5000";
	}
}
